import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import base64
import json
import os
import time
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
from Crypto.Hash import SHA256, SHA512
from Crypto.Signature import pkcs1_15
import threading

# Hàm padding dữ liệu cho AES
def pad(data):
    padding_len = 16 - (len(data) % 16)
    padding = bytes([padding_len] * padding_len)
    return data + padding

# Hàm gửi bệnh án
def sender_process(file_path, password, receiver_public_key, progress_callback=None):
    try:
        # Bước 1: Handshake
        if progress_callback:
            progress_callback(10, "Khởi tạo kết nối...")
        print("Sender: Hello!")
        time.sleep(0.5)  # Giả lập delay
        print("Receiver: Ready!")
        
        if progress_callback:
            progress_callback(20, "Đọc file bệnh án...")
        # Đọc nội dung file
        with open(file_path, 'rb') as f:
            file_data = f.read()
        
        if progress_callback:
            progress_callback(30, "Tạo metadata và chữ ký...")
        # Tạo metadata
        timestamp = str(time.time())
        record_id = "REC12345"
        metadata = f"{file_path}|{timestamp}|{record_id}".encode()
        
        # Tạo khóa RSA cho bác sĩ
        sender_key = RSA.generate(2048)
        sender_private_key = sender_key
        sender_public_key = sender_key.publickey()
        
        if progress_callback:
            progress_callback(50, "Ký số metadata...")
            
        # Ký số metadata
        hash_metadata = SHA512.new(metadata)
        signature = pkcs1_15.new(sender_private_key).sign(hash_metadata)
        
        # Băm mật khẩu
        pwd_hash = SHA256.new(password.encode()).hexdigest()
        
        if progress_callback:
            progress_callback(60, "Tạo khóa mã hóa...")
        # Tạo SessionKey và IV
        session_key = get_random_bytes(32)
        iv = get_random_bytes(16)
        
        if progress_callback:
            progress_callback(70, "Mã hóa file bằng AES-CBC...")
        # Mã hóa file bằng AES-CBC
        cipher_aes = AES.new(session_key, AES.MODE_CBC, iv)
        padded_data = pad(file_data)
        ciphertext = cipher_aes.encrypt(padded_data)
        
        if progress_callback:
            progress_callback(80, "Tính toán hash toàn vẹn...")
        # Tính hash toàn vẹn
        hash_obj = SHA512.new()
        hash_obj.update(iv + ciphertext)
        file_hash = hash_obj.hexdigest()
        
        if progress_callback:
            progress_callback(90, "Mã hóa session key...")
        # Mã hóa SessionKey
        cipher_rsa = PKCS1_OAEP.new(receiver_public_key)
        encrypted_session_key = cipher_rsa.encrypt(session_key)
        
        if progress_callback:
            progress_callback(95, "Tạo gói tin...")
        # Tạo gói tin
        packet = {
            "iv": base64.b64encode(iv).decode(),
            "cipher": base64.b64encode(ciphertext).decode(),
            "hash": file_hash,
            "sig": base64.b64encode(signature).decode(),
            "pwd": pwd_hash,
            "encrypted_session_key": base64.b64encode(encrypted_session_key).decode(),
            "metadata": metadata.decode(),
            "sender_public_key": base64.b64encode(sender_public_key.export_key()).decode()
        }
        
        # Lưu gói tin vào file
        with open("packet.json", "w") as f:
            json.dump(packet, f)
        
        if progress_callback:
            progress_callback(100, "Hoàn thành!")
        
        return packet
        
    except Exception as e:
        if progress_callback:
            progress_callback(0, f"Lỗi: {str(e)}")
        raise e

# Class chính cho giao diện
class MedicalRecordSenderApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("🏥 Hệ Thống Gửi Bệnh Án An Toàn")
        self.root.geometry("800x1200")
        self.root.configure(bg='#f0f8ff')
        self.root.resizable(True, True)

        
        # Tạo khóa RSA cho phòng lưu trữ
        self.receiver_key = RSA.generate(2048)
        self.receiver_public_key = self.receiver_key.publickey()
        
        # Lưu khóa riêng của receiver
        with open("receiver_private_key.pem", "wb") as f:
            f.write(self.receiver_key.export_key())
        
        self.selected_file = ""
        self.create_widgets()
        
    def create_widgets(self):
        # Header Frame
        header_frame = tk.Frame(self.root, bg='#2c3e50', height=100)
        header_frame.pack(fill='x', padx=0, pady=0)
        header_frame.pack_propagate(False)
        
        # Title
        title_label = tk.Label(
            header_frame, 
            text=" HỆ THỐNG GỬI BỆNH ÁN AN TOÀN",
            font=('Arial', 20, 'bold'),
            fg='white',
            bg='#2c3e50'
        )
        title_label.pack(pady=30)
        
        # Main Container
        main_frame = tk.Frame(self.root, bg='#f0f8ff')
        main_frame.pack(fill='both', expand=True, padx=30, pady=20)
        
        # Doctor Info Section
        doctor_frame = tk.LabelFrame(
            main_frame,
            text="👨‍⚕️ Thông Tin Bác Sĩ",
            font=('Arial', 12, 'bold'),
            fg='#2c3e50',
            bg='#f0f8ff',
            padx=20,
            pady=15
        )
        doctor_frame.pack(fill='x', pady=(0, 20))
        
        tk.Label(
            doctor_frame,
            text="Bác sĩ: BS. A B C",
            font=('Arial', 11),
            bg='#f0f8ff',
            fg='#34495e'
        ).pack(anchor='w')
        
        tk.Label(
            doctor_frame,
            text="Khoa: xyz",
            font=('Arial', 11),
            bg='#f0f8ff',
            fg='#34495e'
        ).pack(anchor='w')
        
        tk.Label(
            doctor_frame,
            text="Bệnh viện: Bệnh viện Đa khoa Trung ương",
            font=('Arial', 11),
            bg='#f0f8ff',
            fg='#34495e'
        ).pack(anchor='w')
        
        # File Selection Section
        file_frame = tk.LabelFrame(
            main_frame,
            text="📁 Chọn File Bệnh Án",
            font=('Arial', 12, 'bold'),
            fg='#2c3e50',
            bg='#f0f8ff',
            padx=20,
            pady=15
        )
        file_frame.pack(fill='x', pady=(0, 20))
        
        file_button_frame = tk.Frame(file_frame, bg='#f0f8ff')
        file_button_frame.pack(fill='x')
        
        self.choose_btn = tk.Button(
            file_button_frame,
            text="🔍 Chọn File Bệnh Án",
            command=self.choose_file,
            font=('Arial', 11, 'bold'),
            bg='#3498db',
            fg='white',
            relief='flat',
            padx=20,
            pady=10,
            cursor='hand2'
        )
        self.choose_btn.pack(side='left')
        
        self.file_label = tk.Label(
            file_button_frame,
            text="Chưa chọn file",
            font=('Arial', 10),
            bg='#f0f8ff',
            fg='#7f8c8d',
            wraplength=400
        )
        self.file_label.pack(side='left', padx=(20, 0))
        
        # Password Section
        pwd_frame = tk.LabelFrame(
            main_frame,
            text="🔐 Xác Thực Mật Khẩu",
            font=('Arial', 12, 'bold'),
            fg='#2c3e50',
            bg='#f0f8ff',
            padx=20,
            pady=15
        )
        pwd_frame.pack(fill='x', pady=(0, 20))
        
        tk.Label(
            pwd_frame,
            text="Nhập mật khẩu xác thực:",
            font=('Arial', 11),
            bg='#f0f8ff',
            fg='#34495e'
        ).pack(anchor='w', pady=(0, 5))
        
        self.pwd_entry = tk.Entry(
            pwd_frame,
            show="*",
            font=('Arial', 12),
            width=30,
            relief='solid',
            bd=1
        )
        self.pwd_entry.pack(anchor='w', pady=(0, 10))
        
        # Show/Hide Password
        self.show_pwd_var = tk.BooleanVar()
        show_pwd_check = tk.Checkbutton(
            pwd_frame,
            text="Hiển thị mật khẩu",
            variable=self.show_pwd_var,
            command=self.toggle_password,
            font=('Arial', 10),
            bg='#f0f8ff',
            fg='#34495e'
        )
        show_pwd_check.pack(anchor='w')
        
        
        # Progress Section
        progress_frame = tk.LabelFrame(
            main_frame,
            text="📊 Tiến Trình Xử Lý",
            font=('Arial', 12, 'bold'),
            fg='#2c3e50',
            bg='#f0f8ff',
            padx=20,
            pady=15
        )
        progress_frame.pack(fill='x', pady=(0, 20))
        
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(
            progress_frame,
            variable=self.progress_var,
            maximum=100,
            length=400,
            mode='determinate'
        )
        self.progress_bar.pack(pady=(0, 10))
        
        self.status_label = tk.Label(
            progress_frame,
            text="Sẵn sàng gửi file...",
            font=('Arial', 10),
            bg='#f0f8ff',
            fg='#34495e'
        )
        self.status_label.pack()
        
        # Action Buttons
        button_frame = tk.Frame(main_frame, bg='#f0f8ff')
        button_frame.pack(fill='x', pady=20)
        
        self.send_btn = tk.Button(
            button_frame,
            text=" GỬI BỆNH ÁN AN TOÀN",
            command=self.send_file_threaded,
            font=('Arial', 14, 'bold'),
            bg='#e74c3c',
            fg='white',
            relief='flat',
            padx=30,
            pady=15,
            cursor='hand2'
        )
        self.send_btn.pack(side='left', padx=(0, 20))
        
        reset_btn = tk.Button(
            button_frame,
            text=" Đặt Lại",
            command=self.reset_form,
            font=('Arial', 12, 'bold'),
            bg='#95a5a6',
            fg='white',
            relief='flat',
            padx=20,
            pady=15,
            cursor='hand2'
        )
        reset_btn.pack(side='left')
        
        # Footer
        footer_frame = tk.Frame(self.root, bg='#34495e', height=50)
        footer_frame.pack(fill='x', side='bottom')
        footer_frame.pack_propagate(False)
        
        tk.Label(
            footer_frame,
            text="© 2024 Hệ Thống Y Tế An Toàn - Tuân thủ tiêu chuẩn bảo mật HIPAA",
            font=('Arial', 9),
            fg='white',
            bg='#34495e'
        ).pack(pady=15)
        
        # Hover effects
        self.add_hover_effects()
        
    def add_hover_effects(self):
        """Thêm hiệu ứng hover cho các nút"""
        def on_enter(e, color):
            e.widget.config(bg=color)
        
        def on_leave(e, color):
            e.widget.config(bg=color)
        
        # Choose button hover
        self.choose_btn.bind("<Enter>", lambda e: on_enter(e, '#2980b9'))
        self.choose_btn.bind("<Leave>", lambda e: on_leave(e, '#3498db'))
        
        # Send button hover
        self.send_btn.bind("<Enter>", lambda e: on_enter(e, '#c0392b'))
        self.send_btn.bind("<Leave>", lambda e: on_leave(e, '#e74c3c'))
    
    def toggle_password(self):
        """Hiển thị/ẩn mật khẩu"""
        if self.show_pwd_var.get():
            self.pwd_entry.config(show="")
        else:
            self.pwd_entry.config(show="*")
    
    def choose_file(self):
        """Chọn file bệnh án"""
        file_path = filedialog.askopenfilename(
            title="Chọn File Bệnh Án",
            filetypes=[
                ("Text files", "*.txt"),
                ("PDF files", "*.pdf"),
                ("Word files", "*.docx"),
                ("All files", "*.*")
            ]
        )
        if file_path:
            self.selected_file = file_path
            filename = os.path.basename(file_path)
            self.file_label.config(
                text=f" Đã chọn: {filename}",
                fg='#27ae60'
            )
            self.choose_btn.config(text="✏️ Thay Đổi File")
    
    def update_progress(self, value, status):
        """Cập nhật thanh tiến trình"""
        self.progress_var.set(value)
        self.status_label.config(text=status)
        self.root.update_idletasks()
    
    def send_file_threaded(self):
        """Gửi file trong thread riêng để không block UI"""
        if not self.selected_file:
            messagebox.showerror("❌ Lỗi", "Vui lòng chọn file bệnh án!")
            return
        
        password = self.pwd_entry.get().strip()
        if not password:
            messagebox.showerror("❌ Lỗi", "Vui lòng nhập mật khẩu xác thực!")
            return
        
        # Disable button during processing
        self.send_btn.config(state='disabled', text="⏳ Đang xử lý...")
        
        def send_worker():
            try:
                packet = sender_process(
                    self.selected_file, 
                    password, 
                    self.receiver_public_key,
                    self.update_progress
                )
                
                # Show success message
                self.root.after(0, lambda: messagebox.showinfo(
                    " Thành Công", 
                    "Bệnh án đã được gửi an toàn!\n\n"
                    " Gói tin đã lưu: packet.json\n"
                    " Dữ liệu đã được mã hóa và ký số\n"
                    " Kiểm tra toàn vẹn: Hoàn tất"
                ))
                
                # Reset progress after success
                time.sleep(2)
                self.root.after(0, lambda: self.update_progress(0, "Sẵn sàng gửi file tiếp theo..."))
                
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror(
                    "❌ Lỗi", 
                    f"Không thể gửi file:\n{str(e)}"
                ))
                self.root.after(0, lambda: self.update_progress(0, "Lỗi xử lý!"))
            
            finally:
                # Re-enable button
                self.root.after(0, lambda: self.send_btn.config(
                    state='normal', 
                    text="📤 GỬI BỆNH ÁN AN TOÀN"
                ))
        
        # Start worker thread
        thread = threading.Thread(target=send_worker, daemon=True)
        thread.start()
    
    def reset_form(self):
        """Đặt lại form"""
        self.selected_file = ""
        self.file_label.config(text="Chưa chọn file", fg='#7f8c8d')
        self.pwd_entry.delete(0, tk.END)
        self.progress_var.set(0)
        self.status_label.config(text="Sẵn sàng gửi file...")
        self.choose_btn.config(text="🔍 Chọn File Bệnh Án")
        self.show_pwd_var.set(False)
        self.pwd_entry.config(show="*")
    
    def run(self):
        """Chạy ứng dụng"""
        # Tạo file mẫu nếu chưa có
        if not os.path.exists("medical_record.txt"):
            with open("medical_record.txt", "w", encoding='utf-8') as f:
                f.write("""BỆNH ÁN ĐIỆN TỬ
==============================
Mã bệnh án: BN001234
Bác sĩ điều trị: BS. Nguyễn Thị Hoa
Ngày khám: 15/12/2024

THÔNG TIN BỆNH NHÂN:
- Họ tên: Trần Văn Nam
- Tuổi: 45
- Giới tính: Nam
- Địa chỉ: Hà Nội

CHẨN ĐOÁN:
- Chẩn đoán: Viêm dạ dày cấp
- Triệu chứng: Đau bụng, buồn nôn
- Kết quả xét nghiệm: Bình thường

ĐIỀU TRỊ:
- Thuốc kê đơn: Omeprazole 20mg
- Lời khuyên: Ăn uống điều độ

Bác sĩ ký tên
BS. Nguyễn Thị Hoa""")
        
        self.root.mainloop()

if __name__ == "__main__":
    app = MedicalRecordSenderApp()
    app.run()