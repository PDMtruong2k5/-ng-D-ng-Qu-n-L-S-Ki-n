# --- receiver_gui.py ---

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import base64, json, os
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256, SHA512
from Crypto.Signature import pkcs1_15

# Bỏ padding AES
def unpad(data):
    padding_len = data[-1]
    return data[:-padding_len]

# Xử lý gói tin
def process_packet(packet_file, password, private_key):
    try:
        with open(packet_file, 'r') as f:
            packet = json.load(f)

        iv = base64.b64decode(packet['iv'])
        cipher = base64.b64decode(packet['cipher'])
        sig = base64.b64decode(packet['sig'])
        pwd_hash_received = packet['pwd']
        encrypted_session_key = base64.b64decode(packet['encrypted_session_key'])
        metadata = packet['metadata'].encode()
        sender_public_key = RSA.import_key(base64.b64decode(packet['sender_public_key']))

        # Kiểm tra mật khẩu
        pwd_hash_expected = SHA256.new(password.encode()).hexdigest()
        if pwd_hash_received != pwd_hash_expected:
            return False, "❌ Mật khẩu không đúng."

        # Xác minh chữ ký số
        pkcs1_15.new(sender_public_key).verify(SHA512.new(metadata), sig)

        # Kiểm tra toàn vẹn
        if SHA512.new(iv + cipher).hexdigest() != packet['hash']:
            return False, "❌ Dữ liệu bị thay đổi (sai hash)."

        # Giải mã session key
        cipher_rsa = PKCS1_OAEP.new(private_key)
        session_key = cipher_rsa.decrypt(encrypted_session_key)

        # Giải mã nội dung file
        cipher_aes = AES.new(session_key, AES.MODE_CBC, iv)
        decrypted = unpad(cipher_aes.decrypt(cipher))

        # Ghi file
        with open("benh_an_da_giai_ma.txt", "wb") as f:
            f.write(decrypted)

        return True, "✅ Gói tin hợp lệ. Đã lưu file bệnh án."

    except Exception as e:
        return False, f"❌ Lỗi: {str(e)}"

class ReceiverApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("📥 Trạm Nhận Bệnh Án")
        self.root.geometry("600x420")
        self.root.configure(bg='#eaf6fb')
        self.root.resizable(False, False)
        self.create_widgets()

        if os.path.exists("receiver_private_key.pem"):
            with open("receiver_private_key.pem", "rb") as f:
                self.private_key = RSA.import_key(f.read())
        else:
            self.private_key = None

    def create_widgets(self):
        # Header
        header = tk.Frame(self.root, bg='#3498db', height=80)
        header.pack(fill='x')
        header.pack_propagate(False)
        tk.Label(
            header, text="📥 TRẠM NHẬN BỆNH ÁN AN TOÀN", fg='white', bg='#3498db',
            font=('Arial', 20, 'bold')
        ).pack(pady=20)

        # Main frame
        main = tk.Frame(self.root, bg='#eaf6fb')
        main.pack(fill='both', expand=True, padx=0, pady=0)

        # Card frame (bo góc, nổi bật)
        card = tk.Frame(main, bg='white', bd=2, relief='groove')
        card.place(relx=0.5, rely=0.5, anchor='center', width=420, height=280)

        # Hướng dẫn
        guide = tk.Label(
            card, 
            text="Vui lòng nhập mật khẩu xác thực và chọn gói tin bệnh án để giải mã.",
            bg='white', fg='#2980b9', font=('Arial', 11, 'italic'),
            wraplength=360, justify='center'
        )
        guide.pack(pady=(18, 8), padx=10)

        # Nhập mật khẩu
        pwd_label = tk.Label(card, text="🔐 Nhập mật khẩu xác thực:", bg='white', font=('Arial', 12, 'bold'), fg='#34495e')
        pwd_label.pack(anchor='w', padx=30)
        self.pwd_entry = tk.Entry(card, show='*', width=28, font=('Arial', 12))
        self.pwd_entry.pack(pady=5, padx=30, anchor='w')

        # Nút chọn gói tin
        self.select_btn = tk.Button(
            card, text="📂 Chọn gói tin", command=self.select_packet,
            bg='#3498db', fg='white', font=('Arial', 12, 'bold'), activebackground='#217dbb', activeforeground='white', bd=0, cursor='hand2', height=1, width=18
        )
        self.select_btn.pack(pady=15)
        self.select_btn.bind('<Enter>', lambda e: self.select_btn.config(bg='#217dbb'))
        self.select_btn.bind('<Leave>', lambda e: self.select_btn.config(bg='#3498db'))

        # Thông báo kết quả
        self.result_label = tk.Label(card, text="", bg='white', font=('Arial', 12, 'bold'), fg='#27ae60')
        self.result_label.pack(pady=(10, 0))

    def select_packet(self):
        file = filedialog.askopenfilename(filetypes=[("JSON files", "*.json")])
        if not file:
            return
        password = self.pwd_entry.get().strip()
        if not password:
            messagebox.showwarning("Thiếu thông tin", "Vui lòng nhập mật khẩu để xác thực.")
            return
        if not self.private_key:
            messagebox.showerror("Lỗi khóa", "Không tìm thấy khóa riêng receiver.")
            return
        ok, msg = process_packet(file, password, self.private_key)
        self.result_label.config(text=msg, fg='#27ae60' if ok else '#e74c3c')
        if ok:
            self.result_label.after(100, lambda: self.result_label.config(fg='#27ae60'))
        else:
            self.result_label.after(100, lambda: self.result_label.config(fg='#e74c3c'))
    
    def run(self):
        self.root.mainloop()

if __name__ == '__main__':
    app = ReceiverApp()
    app.run()